Use this directory to contribute 3rd-party extensions to the Maven core. These extensions can either extend or override
Maven's default implementation.
