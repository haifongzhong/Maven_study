package org.example.dao;

/**
 * @className: userDao
 * @description: TODO
 * @author: haifongzhong
 * @date: 2023/03/08 10:52
 * @Company: Copyright© [2023/03/08] by [heifongzhong]
 **/

public class UserDao {
    public static void testDao(){
        System.out.println("userDao test ...");
    }
    
}
