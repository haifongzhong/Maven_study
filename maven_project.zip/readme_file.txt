#######################################################################################
################################## 配置maven项目 #######################################
#######################################################################################



## maven_package  》》  maven_moude


# maven_package （基于javaweb） 下存在三个资源版本，分别是  dev——本地版本、 test——测试版本、 product——正式版本


##分别使用三种打包方式实现三种开发环境下的打包

## maven_package_dev
clean compile package -Dmaven.test.skip=true

## maven_package_test
clean compile package -Ptest -Dmaven.test.skip=true

## maven_package_product
clean compile package -Pproduct -Dmaven.test.skip=true

# maven_moude 多模块开发

## 包含一个父模块和三个子模块 ： maven_parent——父模块； maven_dao——dao层模块； maven_service——service层模块； maven_controller——servlet层模块

## maven_service 引入maven_dao依赖
## maven_controller 引入maven_service依赖；添加tomcat&插件

